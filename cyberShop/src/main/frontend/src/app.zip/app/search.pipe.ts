import { Pipe, PipeTransform } from '@angular/core';
import { Product } from './product';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value: Product[], searchTerm: string): Product[] {
    return value.filter(v => v.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }

}
